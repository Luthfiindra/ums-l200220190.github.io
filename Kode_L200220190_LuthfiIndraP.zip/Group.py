import os

# Path file teks
file_paths = [
    r"/mnt/c/Users/Teto/OneDrive/Documents/Tugas/IPSD/ChatWA/Group1.txt",
    r"/mnt/c/Users/Teto/OneDrive/Documents/Tugas/IPSD/ChatWA/Group2.txt"
]

output_file = r"/mnt/c/Users/Teto/OneDrive/Documents/Tugas/IPSD/ChatWA/data.txt"

# Gabungkan file teks
with open(output_file, 'w', encoding='utf-8') as output:
    for file_path in file_paths:
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                output.writelines(f.readlines())
        else:
            print(f"File tidak ditemukan: {file_path}")

print(f"File gabungan disimpan di {output_file}")
